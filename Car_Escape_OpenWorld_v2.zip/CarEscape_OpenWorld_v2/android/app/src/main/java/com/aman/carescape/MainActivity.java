package com.aman.carescape;
import android.app.Activity;
import android.os.Bundle;
import android.view.View;
import android.view.WindowManager;
import android.webkit.WebSettings;
import android.webkit.WebView;
public class MainActivity extends Activity {
 @Override public void onCreate(Bundle state) {
  super.onCreate(state);
  getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN);
  WebView web = new WebView(this);
  web.setBackgroundColor(0xFF071423);
  WebSettings s = web.getSettings();
  s.setJavaScriptEnabled(true); s.setDomStorageEnabled(true); s.setAllowFileAccess(true);
  web.setOverScrollMode(View.OVER_SCROLL_NEVER);
  setContentView(web);
  web.loadUrl("file:///android_asset/index.html");
 }
}
