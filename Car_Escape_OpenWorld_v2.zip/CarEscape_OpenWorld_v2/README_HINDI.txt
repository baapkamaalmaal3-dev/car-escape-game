CAR ESCAPE — OPEN WORLD v2 (APK-BUILD PROJECT)

Kya included hai:
- Fictional open-city driving prototype: city blocks, buildings, roads, highway, coast/beach, hills aur parks.
- Traffic cars, minimap aur landscape mobile steering/gas controls.
- Offline single-player: game chalne ke liye internet ki zaroorat nahi.
- Android WebView app project, jo game ko app ke andar load karta hai.
- GitHub Actions workflow: .github/workflows/build-apk.yml — GitHub par upload karne ke baad APK build karne ke liye.

ZAROORI LIMITATIONS:
- Yeh playable starter/prototype hai, full GTA-scale 3D game nahi.
- 4 phones par hotspot se real offline multiplayer abhi bana hua nahi hai. Is feature ke liye networking, host/join UI aur device testing abhi karni hogi.
- Is ZIP mein pehle se compiled APK nahi hai; APK build karna hoga. Is environment mein Android build/test run nahi kiya gaya.

HTML ko test karna:
web/index.html ko browser mein kholo. START DRIVING dabao; steering aur gas buttons use karo.

ANDROID STUDIO SE APK:
1. ZIP extract karo.
2. Android Studio mein extracted folder ke andar `android` folder ko Open karo.
3. JDK 17 aur Android SDK Platform 35 install/sync hone do.
4. Build > Build APK(s).
5. APK aam taur par android/app/build/outputs/apk/debug/app-debug.apk mein milega.

GITHUB ACTIONS SE APK (computer ki zaroorat nahi ho sakti, browser se bhi kar sakte ho):
1. GitHub par naya repository banao.
2. Is ZIP ko extract karke iske andar ki saari files/folders repository ke root mein upload karo. `.github` folder bhi upload hona chahiye.
3. Commit/push karo. Repository mein Actions tab kholo.
4. `Build Car Escape APK` workflow chalao (Run workflow), ya main branch par push ke baad run hone do.
5. Successful run ke neeche Artifacts se `Car-Escape-debug-APK` download karo; ZIP ke andar `app-debug.apk` hoga.

Build ko internet chahiye ho sakta hai kyunki Gradle aur Android dependencies download hoti hain. Game ka local HTML asset runtime par internet use nahi karta.
